#!/bin/bash

JAVA_HOME=/cad2/ece419s/java/jdk1.6.0/

#${JAVA_HOME}/bin/java Mazewar ug161.eecg.utoronto.ca 3344

${JAVA_HOME}/bin/java NamingServer
