#$1 = port number for the server to run

JAVA_HOME=/cad2/ece419s/java/jdk1.6.0/

#${JAVA_HOME}/bin/java MazeServer 3344

${JAVA_HOME}/bin/java MazeServer $1

